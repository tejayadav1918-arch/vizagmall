import React from 'react'

const FootExpo = () => {
  return (
    <div>FootExpo</div>
  )
}

export default FootExpo