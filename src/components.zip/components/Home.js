import React from 'react'
import Banner from './Banner'

const Home = () => {
  return (
    <div className="text-center mt-5">
      <Banner />
    </div>
  )
}

export default Home