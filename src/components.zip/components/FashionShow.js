import React from 'react'

const FashionShow = () => {
  return (
    <div>FashionShow</div>
  )
}

export default FashionShow